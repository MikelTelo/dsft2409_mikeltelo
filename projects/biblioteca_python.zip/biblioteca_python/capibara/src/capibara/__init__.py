from . import data_analysis
from . import data_processing
from . import data_visualization
from . import machine_learning

__version__ = '0.1.0' 