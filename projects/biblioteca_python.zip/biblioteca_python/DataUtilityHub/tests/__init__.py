"""
Inicializador del paquete de pruebas
"""
